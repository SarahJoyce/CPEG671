print('AAAABBBBCCCCDDDDEEEE\xef\xbe\xad\xde')
