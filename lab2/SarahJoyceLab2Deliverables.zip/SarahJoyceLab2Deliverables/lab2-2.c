int main(){
  int a = 10;
  int b = 14;
  int c = a - b;
  if(c >= 0){
   a = 2;
  }else{
   a = 1;
  }return a;
}
