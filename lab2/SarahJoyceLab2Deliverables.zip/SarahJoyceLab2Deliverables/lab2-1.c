int main(){
  int a = 32;
  int b = 46;
  int c = 55;
  c = c + b + a;
  return c;
}
